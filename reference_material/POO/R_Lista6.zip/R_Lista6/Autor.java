
public class Autor
{
    String nome, titulacao;
}
