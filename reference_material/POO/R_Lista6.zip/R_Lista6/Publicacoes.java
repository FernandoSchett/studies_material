public class Publicacoes
{
    String data, titulo;
    Publicacoes referencias[];
    Autor autores[];  
    int Tref=0, tautores=0;
}
