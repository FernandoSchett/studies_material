public class Livro_ extends Publicacoes
{
    int ISBN;
    String editora, edicao;
}
