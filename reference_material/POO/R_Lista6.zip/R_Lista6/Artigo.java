public class Artigo extends Publicacoes
{
    String resumo; 
    
}
