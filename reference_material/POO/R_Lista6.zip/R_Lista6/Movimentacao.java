public class Movimentacao
{   String descricao;
    float valor;
    String tipo;
    
    public Movimentacao(String Descricao, float Valor, String Tipo)
    {  descricao = Descricao;
       valor = Valor;
       tipo = Tipo;
    }   
}
