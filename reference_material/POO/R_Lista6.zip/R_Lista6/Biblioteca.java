public class Biblioteca
{
   String nome, endereço;
   Publicacoes acervo[];
   int Tacervo=0;
}
