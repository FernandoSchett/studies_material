
public class Pessoa
{
   String nome;
   int idade;
   String situacao;
   
   public Pessoa(String n, int i)
   {
       nome = n;
       idade = i;
   }
   
   public int getIdade()
   {
       return idade;
   }
}
