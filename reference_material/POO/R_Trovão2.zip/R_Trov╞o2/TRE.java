public interface TRE
{
    public static final String NV = "Não Vota";
    public static final String VF = "Voto Facultativo";
    public static final String VO = "voto Obrigatório";
    public void calculoDeVotantes(Pessoa obj);
}
